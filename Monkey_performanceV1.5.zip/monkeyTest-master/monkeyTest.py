# -*- coding: utf-8 -*-
import datetime
import time
import math
import xlsxwriter
from Base import AdbCommon
from Base import OperateFile
import re
from Base import BaseCashEmnu as go
from Base import BasePhoneMsg
from Base import BaseReport
from Base import BaseMonitor
from Base import BaseAnalysis
import threading
import os
from Config import Config

PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

def report(app,sumTime,dev):
    run_time = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
    workbook = xlsxwriter.Workbook('report_' + dev + "_" + run_time + '.xlsx')
    bo = BaseReport.OperateReport(workbook)
    header = get_phone(dev)
    worksheet1 = workbook.add_worksheet("性能监控")
    app["maxMen"] = BaseAnalysis.maxMen(BaseMonitor.men)
    app["avgMen"] = BaseAnalysis.avgMen(BaseMonitor.men)
    app["maxCpu"] = BaseAnalysis.maxCpu(BaseMonitor.cpu)
    app["avgCpu"] = BaseAnalysis.avgCpu(BaseMonitor.cpu)
    app["maxFps"] = BaseAnalysis.maxFps(BaseMonitor.fps)
    app["avgFps"] = BaseAnalysis.avgFps(BaseMonitor.fps)
    app["afterBattery"] = BaseMonitor.get_battery(dev)
    _maxFlow = BaseAnalysis.maxFlow(BaseMonitor.flow)
    _avgFLow = BaseAnalysis.avgFlow(BaseMonitor.flow)
    app["maxFlowUp"] = _maxFlow[1]
    app["maxFlowDown"] = _maxFlow[0]
    app["avgFlowUp"] = _avgFLow[1]
    app["avgFlowDown"] = _avgFLow[0]
    header["time"] = sumTime
    header["net"] = app["net"]
    bo.monitor(worksheet=worksheet1, header=header, data=app)
    #print("---monkey_log------")
    #print(app["monkey_log"])
    #get_error(log=app["monkey_log"])
    crash = []
    with open(app["monkey_log"], encoding="utf-8") as monkey_log:
        lines = monkey_log.readlines()
        for line in lines:
            if re.findall(go.ANR, line):
                print("存在anr错误:" + line)
                crash.append(line)
            if re.findall(go.CRASH, line):
                print("存在crash错误:" + line)
                crash.append(line)
            if re.findall(go.EXCEPTION, line):
                print("存在crash错误:" + line)
                crash.append(line)
    if len(crash):
        worksheet2 = workbook.add_worksheet("异常日志")
        bo.crash(worksheet2, crash)

    worksheet3 = workbook.add_worksheet("详细信息")
    app = {}
    app["cpu"] = BaseMonitor.cpu
    app["men"] = BaseMonitor.men
    app["flow"] = BaseMonitor.flow
    app["battery"] = BaseMonitor.battery[2:]
    app["fps"] = BaseMonitor.fps
    bo.analysis(worksheet3, app)
    bo.close()

 # 手机信息
def get_phone(dev):
    bg = BasePhoneMsg.getPhone("log.txt").get_phone_Kernel(dev)
    app = {}
    app["phone_name"] = bg[0]["phone_name"] + "_" + bg[0]["phone_model"]
    app["pix"] = bg[3]
    app["rom"] = bg[1]
    app["kel"] = bg[2]
    return app

#开始脚本测试
def start_monkey(dev):
    print("---------------------------开始启动monkey------------------------")
    print("start monkey with %s" % dev)
    path_log = Config.log_location + dev
    device_dir = os.path.exists(path_log)
    if device_dir:
        print("Folder Exist, go on testing!")
    else:
        os.mkdir(path_log)  # 按设备ID生成日志目录文件夹
    run_time = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
    # Monkey测试结果日志:monkey_log
    adb_monkey = "shell monkey -p %s -s %s %s" %(Config.package_name,Config.monkey_seed,Config.monkey_parameters)
    monkey_log = path_log + "\\" + run_time + "monkey.log"
    cmd_monkey= "adb -s %s %s > %s" %(dev,adb_monkey,monkey_log)

    os.popen(cmd_monkey)
    print("monkey 命令:",cmd_monkey)

    # Monkey时手机日志,logcat
    logcat_log = path_log + "\\" + run_time + "logcat.log"
    cmd_logcat = "adb -s " + dev + " logcat -d > %s" % (logcat_log)
    os.popen(cmd_logcat)
    #print("logcat 命令:", cmd_logcat)

    # "导出traces文件"
    traces_log = path_log + "\\" + run_time + "traces.log"
    cmd_traces = "adb -s " + dev + " shell cat /data/anr/traces.txt > %s" % traces_log
    os.popen(cmd_traces)
    #print("traces 命令:", cmd_traces)

    beforeBattery = BaseMonitor.get_battery(dev)
    time.sleep(2)
    starttime = datetime.datetime.now()
    while True:
        with open(monkey_log, encoding='utf-8') as monkeylog:
            #print("----------------------采集--------------------------")
            BaseMonitor.get_cpu(Config.package_name, dev)
            BaseMonitor.get_men(Config.package_name, dev)
            BaseMonitor.get_fps(Config.package_name, dev)
            BaseMonitor.get_battery(dev)
            BaseMonitor.get_flow(Config.package_name, Config.net, dev)
            time.sleep(2)
            if monkeylog.read().count('Monkey finished') > 0:
                endtime = datetime.datetime.now()
                print(dev + ":测试完成")
                app = {"beforeBattery": beforeBattery, "net": Config.net, "monkey_log": monkey_log}
                report(app, str((endtime - starttime).seconds) + "秒", dev)
                break

class MonkeyThread(threading.Thread):
    def __init__(self, dev, dev_model):
        threading.Thread.__init__(self)
        self.thread_stop = False
        self.dev = dev
        self.dev_model = dev_model

    def run(self):
        time.sleep(2)
        start_monkey(self.dev)

def create_threads_monkey(device_dict):
    thread_instances = []
    #print("Start new thread")
    if device_dict != {}:
        for id_device, model_device in device_dict.items():
            dev_model = model_device
            dev = id_device
            instance = MonkeyThread(dev, dev_model)
            thread_instances.append(instance)
        for instance in thread_instances:
            instance.start()

if __name__ == '__main__':
    ba = AdbCommon.AndroidDebugBridge()
    if ba.attached_devices():
        BaseMonitor.monitor_device()
    else:
        print("设备不存在")